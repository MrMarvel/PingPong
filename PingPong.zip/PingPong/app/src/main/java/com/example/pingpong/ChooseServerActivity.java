package com.example.pingpong;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.example.pingpong.databinding.ChooseServerMainBinding;

public class ChooseServerActivity extends AppCompatActivity {
    private ChooseServerMainBinding bind;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        bind = ChooseServerMainBinding.inflate(getLayoutInflater());
        setContentView(bind.getRoot());
        Button connectBtn = bind.connectBtn;
        connectBtn.setOnClickListener(view -> {
            Intent toDebugScreen = new Intent(ChooseServerActivity.this, DebugGyroActivity.class);
            startActivity(toDebugScreen);
            /*Snackbar.make(view, "CONNECT ACTION REPLACEMENT", Snackbar.LENGTH_LONG).setAction("?", view1 -> {
            }).show();*/
            //Попытка подключения асинхронно
            //В случае успеха:

        });
    }

    @Override
    protected void onSaveInstanceState(@NonNull Bundle outState) {
        super.onSaveInstanceState(outState);
    }

    @Override
    protected void onRestoreInstanceState(@NonNull Bundle savedInstanceState) {
        super.onRestoreInstanceState(savedInstanceState);
    }
}
