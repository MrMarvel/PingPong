package com.example.pingpong;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;

public class SensorService extends Service {
    public SensorService() {
    }
    //W.I.P.
    //Здесь будет сбор данных с датчиков в ЧЁРНОМ ЭКРАНЕ ТЕЛЕФОНА(ФОНОВАЯ РАБОТА)

    @Override
    public IBinder onBind(Intent intent) {
        //Заглушка
        // TODO: Return the communication channel to the service.
        throw new UnsupportedOperationException("Not yet implemented");
    }
}